module.exports = config = {
    "name" : "Application",
    "favicon" : "--foo--",

    "facebook" : {
        application_id : "--- ADD APP ID HERE ---",
        application_secret : "--- APP APP SECRET HERE ---"
    }
}
