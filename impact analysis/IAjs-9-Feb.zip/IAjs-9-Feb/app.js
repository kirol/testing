var express = require('express');
var passport = require('passport');
var FacebookStrategy = require('passport-facebook').Strategy;
var engine = require('ejs-locals');
var path = require('path');
//var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
//var users = require('./routes/users');
var test = require('./routes/test');

var config = require('./config');
const util = require('util');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.engine('ejs', engine);
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));

/*app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));*/

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: false}));

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'views')));
// config facebook login
app.use(passport.initialize());
app.use(passport.session());
// Use the FacebookStrategy within Passport.
//   Strategies in Passport require a `verify` function, which accept
//   credentials (in this case, an accessToken, refreshToken, and Facebook
//   profile), and invoke a callback with a user object.
passport.use(new FacebookStrategy({
        clientID: config.facebook.application_id,
        clientSecret: config.facebook.application_secret,
        callbackURL: "http://www.figueiredos.com:3000/auth/facebook/callback"
    },
    function(accessToken, refreshToken, profile, done) {
        // asynchronous verification, for effect...
        process.nextTick(function() {

            // To keep the example simple, the user's Facebook profile is returned to
            // represent the logged-in user.  In a typical application, you would want
            // to associate the Facebook account with a user record in your database,
            // and return that user instead.
            console.log(profile);
            return done(null, profile);
        });
    }
));

//ajax
var bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
//here we import the file which has our loadJson and writeJson functions

app.use(bodyParser.json());
/*app.post('/process_save',function (req, res, next) {
    var fs = require('fs');
    fs.writeFile('views/json/stateChart.json', Object.keys(req.body)[0], function (err) {
        if (err) {
            console.log(err);
            return console.log(err);
        }
    });
});*/

/*app.get('/process_load',function (req, res, next) {
    var fs = require('fs');
    var data=fs.readFileSync('json/stateChart.json', 'utf8');
    res.end(data);
});*/


// handle file upload
var formidable = require('formidable');

function isOdd(num) {
    return num % 2;
}

app.post('/IAtool', function(req, res) {
    var form = new formidable.IncomingForm();
    var jsonFileType = /\b\.json\b/;
    var jarFileType = /\b\.jar\b/;

    form.parse(req);

    // fileBegin emits whenever a new file is detected in the upload stream
    form.on('fileBegin', function(name, file) {
        if (jsonFileType.test(file.name) === true) {

            file.path = __dirname + '/views/json/test.json';
            console.log("Upload json file type");
        } else if (jarFileType.test(file.name) === true) {
            console.log("Upload jar file type");
            file.path = 'tattletale/LibraryJTP.jar';
        }
    });



    // file emits whenever a file has been received
    form.on('file', function(name, file) 
    {
        if (jsonFileType.test(file.name) === true) 
        {
            res.redirect('/IAtool');
        }
        else if (jarFileType.test(file.name) === true) 
        {
            console.log("Finish upload jar file");
            const spawnSync = require('child_process').spawnSync;
            var ls = spawnSync('java', ['-jar', 'CDA.jar', '-d', 'tattletale/LibraryJTP.jar']);
            res.redirect('/IAtool');
            


            // Use spawnSync to wait until java -jar command completes before going to next cmd
            /*const spawnSync = require('child_process').spawnSync;
            var ls = spawnSync('java', ['-jar', 'tattletale/tattletale.jar', 'tattletale/LibraryJTP.jar', 'views/output']);

            // Read and return the dependencies between classes 
            var fs = require('fs');
            
            fs.readFile('views/output/classdependson/index.html', 'utf8', function(err, data) 
            {
                if (err) 
                {
                    return console.log(err);
                }
                var jsdom = require("jsdom");
                var notUniqArray = [];
                var linkArray = [];
                var tmpObj0 = {};
                var tmpObj1 = {};
                jsdom.env(data, ["http://code.jquery.com/jquery.js"], function(err, windowx) 
                {
                    windowx.$("td").each(function(index) 
                    {
                        if (isOdd(index) === 1) {
                            var tmpArray = windowx.$(this).text().split(', ');
                            
                            notUniqArray = notUniqArray.concat(tmpArray);
                            for (iTmpArray=0;iTmpArray < tmpArray.length;iTmpArray++){
                                
                                for(var k_tmpObj0 in tmpObj0) tmpObj1[k_tmpObj0]=tmpObj0[k_tmpObj0];
                                tmpObj1["to"] = tmpArray[iTmpArray];
                               
                                linkArray.push(tmpObj1);

                                tmpObj1 = {};
                                
                            }
                            tmpObj0 = {};
                            
                        } else {
                            notUniqArray.push(windowx.$(this).text());
                            tmpObj0 = {"from": windowx.$(this).text(), "color":"#2F4F4F", "thick":1.5, "category":"Dependency"};
                        }
                    });

                    // Create unique array from not unique array

                    var uniqArray = [];
                    windowx.$.each(notUniqArray, function(i, el) {
                        if (windowx.$.inArray(el, uniqArray) === -1) uniqArray.push(el);
                    });


                    var nodeArray = [];

                    for (iUniqArray = 0; iUniqArray < uniqArray.length; iUniqArray++) {
                        nodeArray.push({"category":"UndesiredEvent","id": uniqArray[iUniqArray], "text":uniqArray[iUniqArray],"color":"lightyellow"});
                    }
                    var testJson = {
                        "class": "go.GraphLinksModel",
                        "nodeKeyProperty": "id",
                        "nodeDataArray": nodeArray,
                        "linkDataArray": linkArray
                    };
                    
                    testJson = JSON.stringify(testJson,4,null);
                    
                    fs.writeFile('views/json/test.json', testJson, 'utf8');



                    res.redirect('/IAtool');

                });
            });*/



        }
    });

});

app.get('/process_load_json', function(req, res, next) {
    var fs = require('fs');
    var data = fs.readFileSync('views/json/test.json', 'utf8');
    res.end(data);
});

app.post('/process_save_json', function(req, res, next) {
    //console.log(Object.keys(req.body)[0]);
    var fs = require('fs');
    fs.writeFile('views/json/test.json', Object.keys(req.body)[0], function(err) {
        if (err) {
            console.log(err);
            return console.log(err);
        }
    });
    res.end("OK");
});

//Forward_reasoning algorithm

function Unified(S, conds, conc) {
	var variableArray = ["x", "y","z"];
    var mystore = [];
    var new_conds_delta = [];
    var unifiable = false;
    var func_S = S["func"];
    var new_conds = [];
    for (i in conds) {
        var func_i = conds[i]["func"];
        if (func_S != func_i) {
            new_conds.push(conds[i]);
        } else {
            if (S["params"].length == conds[i]["params"].length) {
                var count = 0;
                for (k in S["params"]) {
                    if (S["params"][k] == conds[i]["params"][k]) {
                        count += 1;
                    }
                }
                for (j in conds[i]["params"]) {
                    var key = conds[i]["params"][j];
                    if (variableArray.indexOf(key) >= 0) {
                        var test = {};
                        test[key] = S["params"][j];
                        mystore.push(test);
                    }

                }

                if (mystore.length == S["params"].length - count) {
                    unifiable = true;
                }


            } else {
                new_conds.push(conds[i]);
            }

        }
    }
    //mystore
    
    for (i in new_conds) {
        var cond = new_conds[i];
        var cond_params = cond["params"];
        var new_params = [];
        for (i in cond_params) {
            var param = cond_params[i];
            //console.log(param);
            var new_param = param;
            for (j in mystore) {
                var item = mystore[j];
                for (key in item) {
                    if (param == key) {
                        new_param = item[key];
                        break;
                    }
                }
            }
            new_params.push(new_param);
        }
        var new_cond = {
            "func": cond["func"],
            "params": new_params
        };
        new_conds_delta.push(new_cond);
    }

    //Generate new conclusion
    var new_conc_params = [];
    for (i in conc["params"]) {
        var param = conc["params"][i];
        var new_param = param;
        for (j in mystore) {
            var item = mystore[j];
            for (key in item) {
                if (param == key) {
                    new_param = item[key];
                    break;
                }
            }
        }
        new_conc_params.push(new_param);
    }

    var new_conc = {
        "func": conc["func"],
        "params": new_conc_params
    }

    return {
        unifiable: unifiable,
        conds: new_conds_delta,
        conc: new_conc
    };
}

function add_conc(conc, facts) {
    var funcFound = false;
    for (i in facts) {
        var fact = facts[i];
        if (JSON.stringify(fact) == JSON.stringify(conc)) {
            funcFound = true;
            break;
        }
    }

    if (!funcFound) {
        facts.push(conc);
    }

    return facts
}

function For_Chain(conds, conc, facts) {
	//console.log(conds);
    for (i in facts) {
        var S = facts[i];
        var unifyObj = Unified(S, conds, conc);
        if (unifyObj.unifiable) {
            if (unifyObj.conds.length == 0) {
                facts = add_conc(unifyObj.conc, facts);
            } else {
                For_Chain(unifyObj.conds, unifyObj.conc, facts);
            }
            //break;
        } else {
        }


    }
    return facts;
}

//Forward_reasoning algorithm
//Get rules
function getRules(){
	var rules=[];
	var fs = require('fs');
	rules=JSON.parse(fs.readFileSync('rules/rules.json', 'utf8'));
	return rules;
}

function compareArray(arr1,arr2){
	if (arr1==null && arr2==null){return true;}
	if (arr1==null || arr2==null){return false;}
	if (arr1.length!=arr2.length){console.log("two array has different length");console.log(arr1);console.log(arr2);return false;}
	var arr1String=[];
	console.log("compare two array: ");
	console.log(arr1);
	console.log(arr2);
	for (i in arr1){
		arr1String.push( JSON.stringify(arr1[i]).trim() );
	}
	
	for (j in arr2){
		var ele2=arr2[j];
		if (arr1String.indexOf( JSON.stringify(ele2).trim() )<0){
			console.log("two array is not equal");
			return false;
		}
	}
	console.log("two array equal");
	return true;
}

function nodeInDiagram(node,diagramNodes){
	for (node_i in diagramNodes){
		//console.log(diagramNodes[i]["id"]);
		if ( node["id"]==diagramNodes[node_i]["id"] ){
			return true;
		}
	}
	//console.log("node is not in diagram");
	//console.log(node["id"]);
	return false;
}

function isNewNode(node,data){
	for (i in data["nodeDataArray"]){
		var compareNode=data["nodeDataArray"][i];
		if (compareNode["id"]==node["id"]){
			return false;
		}
	}
	
	return true;
}

function isNodeHasChanged(node,data){
	if (node.function != null) {
		console.log("node change with reason change function");
		return true;
    }
	
	if ( isNewNode(node,data) ){
		return true;
	}
	
	for ( ii in data["nodeDataArray"] ) {
		if ( node["id"]==data["nodeDataArray"][ii]["id"] ){
			//Module name has changed
			if( node["text"].trim()!=data["nodeDataArray"][ii]["text"].trim() ) {
				return true;
			}
			
			//Attributes have changed
			if( !compareArray( node["list1"], data["nodeDataArray"][ii]["list1"] ) ) {
				return true;
			}
			
			//Methods have change
			if( !compareArray( node["list2"], data["nodeDataArray"][ii]["list2"] ) ) {
				return true;
			}
			
			return false;
		}/*else{
			continue;//continue to check another node in diagram
		}*/
	}
	
	return false;
}

//Generate facts
function generateFacts(sourceData,diagramData){
    var linkData = diagramData["linkDataArray"];
    var nodeData = diagramData["nodeDataArray"];
    //var facts = [ {"func":"CHANGE","params":[-7] }];
	var facts = [];
    //console.log(sourceData);
    //Generate facts from node changed
    //Check from original Diagram to get node deleted.
	var deletedNodeIDs=[];
    for (ori_i in sourceData["nodeDataArray"] ){
    	var curNode=sourceData["nodeDataArray"][ori_i];
    	if ( !nodeInDiagram(curNode,nodeData)){
    		//Node has deleted
    		deletedNodeIDs.push(curNode["id"]);
    		var fact = {
                "func": "CHANGE",
                "params": [curNode["id"]]
            };
            facts.push(fact);
    		
    	}
    }
    
    for (ori_ii in sourceData["linkDataArray"] ){
    	var curLink=sourceData["linkDataArray"][ori_ii];
    	if ( deletedNodeIDs.indexOf(curLink["from"])>=0 || deletedNodeIDs.indexOf(curLink["to"])>=0 ){
    		//Node has deleted
    		var params = [curLink["from"], curLink["to"],curLink["category"]];
            var fact = {
                "func": "LINK",
                "params": params
            };
            facts.push(fact);
    		
    	}
    }
    //console.log(facts);
    //Check from current Diagram
    for (idx in nodeData) {
        var node = nodeData[idx];
        //Verify node has changed
        if(isNodeHasChanged(node,sourceData)){
        	var fact = {
                "func": "CHANGE",
                "params": [node["id"]]
            };
            facts.push(fact);
        }
      //Get modified list data sets
        if (node["database"]!=null){
        	console.log("Node "+node["id"]+" has length of database: "+ Object.keys(node["database"]).length.toString());
        	if( Object.keys(node["database"]).length>0 ) {
            	for(key in node["database"]){
            		var val=node["database"][key];
            		console.log("node database: "+key+" : "+val);
            		
            		if ( val=="Modify" ){
            			var fact = {
        	                "func": "MODIFY",
        	                "params": [node["id"],key]
        	            };
        	            facts.push(fact);
            		}
            		
            		if ( val=="Use" ){
            			var fact = {
        	                "func": "USING",
        	                "params": [node["id"],key]
        	            };
        	            facts.push(fact);
            		}
            	}
            	
	        }else{
	        	console.log("Node does not contain database");
	        }
        } else {
        	//console.log("database is null");
        }
        //Get modified list data sets
    }
    //Generate facts from links
    for (i in linkData) {
        var link = linkData[i];
        var params = [link["from"], link["to"],link["category"]];
        var fact = {
            "func": "LINK",
            "params": params
        };
        facts.push(fact);
    }
    //console.log(facts);
    return facts;
}

//Forward_reasoning
function Forward_reasoning(rules,facts){
	var until = true;
    var dem = 1;
    while (until) {
        var old_facts = [];
        for (i in facts) {
            old_facts.push(facts[i]);
        }
        for (idx in rules) {
            var rule = rules[idx];
            var conds = rule["IF"];
            var conc = rule["THEN"];
            facts = For_Chain(conds, conc, facts);
        }
        if (JSON.stringify(old_facts) == JSON.stringify(facts)) {
            until = false;
        }
        dem += 1;
    }
    return facts;
}
//

function getHighestImpactLevel(nodeID,impact_facts){
	var impact_types=[];
	for (i in impact_facts){
		var impactElement=impact_facts[i];
		if (impactElement["params"][0]==nodeID){
			impact_types.push(impactElement["func"]);
		}
	}
	
	//var impactType="";
	if (impact_types.indexOf("IMPACT-VERYHIGH")>=0){
		return "IMPACT-VERYHIGH";
	}else if (impact_types.indexOf("IMPACT-HIGH")>=0) {
		return "IMPACT-HIGH"
	}else if (impact_types.indexOf("IMPACT-MEDIUM")>=0) {
		return "IMPACT-MEDIUM";
	} else if (impact_types.indexOf("IMPACT-LOW")>=0){
		return "IMPACT-LOW";
	}else if(impact_types.indexOf("IMPACT-VERYLOW")>=0){
		return "IMPACT-VERYLOW";
	}else {
		return "";
	}
}

function checkLinkImpact(link,impact_facts){
	var from=link["from"];
	var to=link["to"];
	var hasFrom=false;
	var hasTo=false;
	for (i in impact_facts){
		var fact=impact_facts[i];
		if (fact["params"][0]==from){
			hasFrom=true;
		}
		if (fact["params"][0]==to){
			hasTo=true;
		}
		if (hasFrom && hasTo){
			break;
		}
		
	}
	
	if (hasFrom && hasTo){
		return true;
	}else{
		return false;
	}
	
}

function changeDiagramColor(sourceData,diagramData, impact_facts) {
	//console.log(diagramData);
    var linkData = diagramData["linkDataArray"];
    var nodeData = diagramData["nodeDataArray"];
    //for cases nodes had deleted
    var deletedNodeIDs=[];
    for (ori_i in sourceData["nodeDataArray"] ){
    	var curNode=sourceData["nodeDataArray"][ori_i];
    	if ( !nodeInDiagram(curNode,nodeData)){
    		//Node has deleted
    		deletedNodeIDs.push(curNode["id"]);
    		nodeData.push(curNode);
    	}
    }
    
    for (ori_ii in sourceData["linkDataArray"] ){
    	var curLink=sourceData["linkDataArray"][ori_ii];
    	if ( deletedNodeIDs.indexOf(curLink["from"])>=0 || deletedNodeIDs.indexOf(curLink["to"])>=0 ){
    		//Node has deleted
    		linkData.push(curLink);
    	}
    }
    //for cases nodes had deleted
    
    //Change color
    for (i in nodeData) {
        var node = nodeData[i];
        var impactLevel=getHighestImpactLevel(node["id"],impact_facts);
        switch(impactLevel) {
            case "IMPACT-VERYHIGH":
            	node["color"] = "red";
                break;
            case "IMPACT-HIGH":
            	node["color"] = "#F08080";
                break;
            case "IMPACT-MEDIUM":
            	node["color"] = "#A52A2A";//Brown
                break;
            case "IMPACT-LOW":
            	node["color"] = "orange";
                break;
            case "IMPACT-VERYLOW":
            	node["color"] = "yellow";
                break;
            default:
            	node["color"] = "lightyellow";
        }
    }
    
    for (j in linkData) {
        var link = linkData[j];
        if ( checkLinkImpact(link,impact_facts) ){
            link["color"] = "red";
            link["thick"] = 3;
        }
    }

    var data = {};
    data["class"] = "go.GraphLinksModel";
    data["nodeKeyProperty"] = "id";
    data["nodeDataArray"] = nodeData;
    data["linkDataArray"] = linkData;
    /*var fs = require('fs');
    fs.writeFileSync('views/json/test1.json', JSON.stringify(data,null,4), 'utf8');*/
    return data;

}

function isInList(listObjs,obj){
	for (i in listObjs){
		if ( JSON.stringify(listObjs[i])==JSON.stringify(obj) ){
			return true;
		}
	}
	return false;
}

function findLevelInList(level,tempImpacts){
	var temp_list=[];
	for (i in tempImpacts){
		var level_i=tempImpacts[i]["level"];
		if(level_i==level){
			var value_i=tempImpacts[i];
			if (!isInList(temp_list,value_i)){
				temp_list.push(value_i);
			}
		}
	}
	//console.log("temp_list_i");
	return temp_list;
}


function getDetailImpactData(modifiedTableList,impact_facts){
	//console.log("getDetailImpactData");
	//console.log(modifiedTableList);
	var fs = require('fs');
    var originalData=JSON.parse(fs.readFileSync('views/json/test.json', 'utf8'));
    var nodeData=originalData["nodeDataArray"];
    var tempImpacts=[];
    for (i in nodeData) {
        var node = nodeData[i];
        var impactLevel=getHighestImpactLevel(node["id"],impact_facts);
        //console.log(impactLevel);
        //console.log(node);
        if (impactLevel!=""){
        	var nodeInfo={};
        	nodeInfo["level"]=impactLevel;
            nodeInfo["id"]=node["id"];
            nodeInfo["name"]=node["text"];
            var tempAttrs=[];
            //console.log("For node data: "+node["id"]);
            //console.log(node);
            if (node["list1"]!=null){
            	for(j in node["list1"]){
                	//"list1":[ {"text":"Attribute 1"},{"text":"Attribute 2"} ]
            		//console.log("list1 info: ");
            		//console.log(node["list1"][j]["text"]);
                	tempAttrs.push(node["list1"][j]["text"]);
                }
            }
            nodeInfo["Attribute"]=tempAttrs;
            var tempMethos=[];
            if (node["list2"]!=null){
            	for(j in node["list2"]){
                	//"list2":[ {"text":"  doConfigSTB()"} ]
                	tempMethos.push(node["list2"][j]["text"]);
                }
            }
            nodeInfo["Operation"]=tempMethos;
            var tempTestcases=[];
            if(node["testcase"]!=null){
            	for(j in node["testcase"]){
                	//"testcase":[ "TC1: Hello World","TC2: Writing sth" ]
                	tempTestcases.push(node["testcase"][j]);
                }
            }
            nodeInfo["Testcases"]=tempTestcases;
            
            var tempTables=[];
            if(node["database"]!=null){
            	for(j in node["database"]){
                	//"database":{"Table 5":"Use", "Table 2":"Modify", "Table 7":"Modify", "Table 6":"Modify"}
                	//if (modifiedTableList.indexOf(j.toString())>=0){
                		tempTables.push(j+" ( "+node["database"][j]+" )");
                	//}
                }
            }
            nodeInfo["Database"]=tempTables;
            
            //console.log(nodeInfo);
            tempImpacts.push(nodeInfo);
            //console.log(tempImpacts);
        }
        
        //var 
    }
    //console.log(tempImpacts);
    //console.log(tempImpacts.length);
    //Group by impactLevel
    /*var detailedData={};
    for (i in tempImpacts){
    	var level_i=tempImpacts[i]["level"];
    	if (Object.keys(detailedData).indexOf(level_i)<0){
    		var list_same_level=findLevelInList(level_i,tempImpacts);
        	console.log("list_same_level: "+level_i);
        	//console.log(list_same_level);
    		detailedData[level_i]=list_same_level;
    	}else{continue;}
    }*/
    var impact_type_lists=["IMPACT-VERYHIGH","IMPACT-HIGH","IMPACT-MEDIUM","IMPACT-LOW","IMPACT-VERYLOW"];
    var detailedData=[];
    for (i in impact_type_lists){
    	var level_i=impact_type_lists[i];
    	var list_same_level=findLevelInList(level_i,tempImpacts);
    	if ( list_same_level.length>0 ){
    		var levelData={};
    		levelData[level_i]=list_same_level;
    		detailedData.push(levelData);
    	}
    	
    }
    
	return detailedData;
}

function getModifyDatabase(facts){
	var modifiedTableList=[];
	//console.log(facts);
	for (i in facts){
		var fact = facts[i];
		if (fact["func"]=="MODIFY"){
			modifiedTableList.push(fact["params"][1]);
		}
	}
	//console.log("getModifyDatabase");
	//console.log(modifiedTableList);
	return modifiedTableList;
}

function getImpactFacts(facts){
	var impact_type_lists=["IMPACT-VERYHIGH","IMPACT-HIGH","IMPACT-MEDIUM","IMPACT-LOW","IMPACT-VERYLOW"];
    var impact_facts = [];
    for (i in facts) {
        var fact = facts[i];
        if (impact_type_lists.indexOf(fact["func"])>=0 ) {
            impact_facts.push(fact);
        }
    }
	return impact_facts;
}

app.post('/process_generate_impact',function (req, res, next) {
	var fs = require('fs');
    var sourceData=JSON.parse(fs.readFileSync('views/json/test.json', 'utf8'));
    //console.log(sourceData);
	var diagramData=JSON.parse(Object.keys(req.body)[0]);
	//console.log(sourceData);
	//Read rules
	var rules=getRules();
	
	var facts=generateFacts(sourceData,diagramData);
    facts=Forward_reasoning(rules,facts);
    //console.log("all facts");
    //console.log(facts);
    var impact_facts=getImpactFacts(facts);
    var model={};
    var data={};
    console.log("my list facts that impacts:");
    console.log(impact_facts);
    var impact=false;
    if ( Object.keys(impact_facts).length>0 ){
    	impact=true;
    	var modelImpact=changeDiagramColor(sourceData,diagramData, impact_facts);
        //console.log({"model":JSON.stringify(model),"data":""});
        var modifiedTableList=getModifyDatabase(facts);
        var dataImpact=getDetailImpactData(modifiedTableList,impact_facts);
    }
    //console.log(data);
    res.end(JSON.stringify({"impact":impact,"model":modelImpact,"data":dataImpact}));
});
//End of ajax

// Passport session setup.
//   To support persistent login sessions, Passport needs to be able to
//   serialize users into and deserialize users out of the session.  Typically,
//   this will be as simple as storing the user ID when serializing, and finding
//   the user by ID when deserializing.  However, since this example does not
//   have a database of user records, the complete Facebook profile is serialized
//   and deserialized.
passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(obj, done) {
    done(null, obj);
});
var report = require('./routes/report');
app.use('/', routes);
//app.use('/users', users);
app.use('/IAtool', test);
app.use('/report', report);
// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function(err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});



module.exports = app;