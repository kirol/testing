#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/HTTPServer.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Net/HTTPRequestHandlerFactory.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/HTMLForm.h>
#include <Poco/Util/ServerApplication.h>
#include <Poco/URI.h>
#include <Poco/Exception.h>
#include <Poco/Net/AcceptCertificateHandler.h>
#include <Poco/Net/KeyConsoleHandler.h>
#include <Poco/Net/PartHandler.h>
#include <Poco/Net/SecureServerSocket.h>
#include <Poco/Net/SSLManager.h>
#include <Poco/Net/NameValueCollection.h>
#include <Poco/DOM/Document.h>
#include <Poco/DOM/Element.h>
#include <Poco/DOM/Text.h>
#include <Poco/DOM/AutoPtr.h>
#include <Poco/DOM/DOMWriter.h>
#include <Poco/XML/XMLWriter.h>
#include <Poco/AutoPtr.h>
#include <Poco/SharedPtr.h>
#include <Poco/InflatingStream.h>
#include <Poco/DeflatingStream.h>
#include <jsoncpp/json/json.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace Poco::Net;
using namespace Poco::Util;
using namespace Json;
using namespace std;

typedef Poco::AutoPtr<Poco::XML::Document> XMLDocPtr;

typedef enum
{
    NONE = 0,
    SEND_GPV,
    SEND_SPV,
    SEND_INVALID = -1
} SendOp;

enum OutputFormat
{
    XML,
    JSON
};

class MyFactoryInterface
{
public:
    virtual vector<string> &getGpvKeyList() = 0;

    virtual SendOp getResponseType() = 0;

    virtual void setResponseType(SendOp responseType) = 0;

    virtual map<string, string> &getSpvKeyValueList() = 0;

    virtual vector<std::string> &getStbMessageList() = 0;

    virtual void addStbMessage(std::string const &message) = 0;

    virtual vector<std::string> &getHttpHeaderList() = 0;

    virtual void addHttpHeaders(std::string const &message) = 0;

    virtual OutputFormat getOutputFormat() = 0;

    virtual void setNextStbResponseStatus(int status) = 0;
    virtual int getNextStbResponseStatus() = 0;
    virtual int getEmptyStbResponseStatus() = 0;
};

class MyRequestHandler : public HTTPRequestHandler
{
public:
    MyRequestHandler(MyFactoryInterface *factory,
                     bool refuseGzip,
                     bool allowGzipResponse)
        : responseType(NONE),
          refuseGzip(refuseGzip),
          allowGzipResponse(allowGzipResponse)
    {
        this->factory = factory;
    }


    virtual void handleRequest(HTTPServerRequest &req, HTTPServerResponse &resp)
    {
        /*
                string const GPVJsonString(
                        "{ \"messageType\": 1,"
                        "\"version\":0,"
                        "\"payload\":{"
                        " \"keys\": "
                        "["
                        "{\"keyName\":\"/Device/Server/Info/RID\"}, "
                        "{\"keyName\":\"/Device/Server/Info/Manufacturer\"}, "
                        "{\"keyName\":\"/Device/Server/Info/Model\"} "
                        "] }}");
        */

        string const GPVJsonString("{ \"messageType\": 1,"
                                   "\"version\":0,"
                                   "\"payload\":{"
                                   " \"keys\": "
                                   "["
                                   "{\"keyName\":\"/Device/Server/Info/\"} "
                                   "] }}");

        //        cout << "handleRequest: entered" << endl;

        try
        {
            if (!isCommand(req))
            {
                cout << "\n***** Received request from STB *****" << endl;
                cout << req.getMethod() << "  " << req.getURI() << endl;
                sendStbResponse(req, resp);
                factory->setResponseType(NONE);
            }
            else
            {
                cout << "\n***** Received command from STB *****" << endl;
                cout << req.getMethod() << "  " << req.getURI() << endl;
                processCommand(req, resp);
            }
        }
        catch(const Poco::Exception & ex)
        {
            std::cout << "\nERROR: " << ex.what() << ": " << ex.message();
            throw;
        }
    }

    SendOp getResponseType() const
    {
        return responseType;
    }

    void setResponseType(SendOp responseType)
    {
        this->responseType = responseType;
    }

private:
    SendOp responseType;
    MyFactoryInterface *factory;
    bool refuseGzip;
    bool allowGzipResponse;
    bool isCommand(HTTPServerRequest &req)
    {
        if (req.getContentType() != "application/json")
        {
            return true;
        }
        // Under certain circumstances, we may have commands distinguished by
        // the uri, independently of content type

        Poco::URI uri(req.getURI());
        if ((uri.getPath().find("/SetResponseData") == 0) ||
            (uri.getPath().find("/ClearSTBMessages") == 0) ||
            (uri.getPath().find("/GetStbMessage") == 0) ||
            (uri.getPath().find("/GetStbMessageHeaders") == 0) ||
            (uri.getPath().find("/GetStbMessageCount") == 0))
        {
            return true;
        }
        return false;
    }

    void sendJsonResponse(HTTPServerResponse &resp,
                          string const &reply,
                          bool gzipResponse = false,
                          bool notOk = false)
    {
        resp.setContentType("application/json");
        sendResponse(resp, reply, gzipResponse, notOk, true);
    }

    void sendResponse(HTTPServerResponse &resp,
                      string const &reply,
                      bool gzipResponse = false,
                      bool notOk = false,
                      bool debug = false)
    {
        if (!notOk)
        {
            resp.setStatusAndReason(HTTPResponse::HTTP_OK);
        }
        // actually don't gzip if the reply is < 1400 bytes
        if (gzipResponse && reply.length() < 1400)
        {
            gzipResponse = false;
        }

        if (!gzipResponse)
        {
            resp.setContentLength(reply.length());
            ostream &out = resp.send();
            out << reply;
            out.flush();
        }
        else
        {
            resp.setChunkedTransferEncoding(true);
            resp.add("Content-Encoding", "gzip");
            ostream &out = resp.send();
            Poco::DeflatingOutputStream deflater(
                out, Poco::DeflatingStreamBuf::STREAM_GZIP);
            deflater << reply;
            deflater.close();
            out.flush();
        }

        if (debug)
        {
            for (Poco::Net::NameValueCollection::ConstIterator iter =
                     resp.begin();
                 iter != resp.end();
                 ++iter)
            {
                cout << iter->first << ": " << iter->second << endl;
            }
            cout << "\n" << reply << endl;
        }
    }

    void processCommand(HTTPServerRequest &req, HTTPServerResponse &resp)
    {
        // cout << "check for command URI" << endl;
        Poco::URI uri(req.getURI());
        // cout << "URI:" << uri.getPathAndQuery() << endl;
        Poco::Net::HTMLForm form;
        form.setFieldLimit(0x10000); //default 100 is not big enough
        form.load(req, req.stream());
        //  cout << "method:" << req.getMethod() << " path:" << uri.getPath()
        //      << endl;
        if (req.getMethod() == "POST")
        {
            if (uri.getPath() == "/SetResponseData")
            {
                //   cout << "GotSetResponseData full query:"
                //         << uri.getPathAndQuery() << "just query:" <<
                // uri.getQuery()
                //        << endl;
                string msgStr(uri.getQuery());
                size_t valuepos = msgStr.find_first_of('=', 0) + 1;
                msgStr.erase(0, valuepos);
                //                cout << "msgStr:" << msgStr << endl;
                if (msgStr == "none")
                {
                    processNoneSetup(resp);
                }
                else if (msgStr == "GPV")
                {
                    processGPVSetup(form, resp);
                }
                else if (msgStr == "SPV")
                {
                    processSPVSetup(form, resp);
                }
                else // bad message type...
                {
                    sendBadRequest(resp);
                }
            }
            else if (uri.getPath() == "/ClearSTBMessages")
            {
                processClearStbMessages(resp);
            }
        }
        else if (req.getMethod() == "GET")
        {
            bool isGzip, acceptGzip;

            getGZipFlags(req, isGzip, acceptGzip);
            if (uri.getPath() == "/GetStbMessage")
            {
                processGetStbMessages(form, resp, acceptGzip);
            }
            else if (uri.getPath() == "/GetStbMessageHeaders")
            {
                processGetHttpHeaders(form, resp, acceptGzip);
            }
            else if (uri.getPath() == "/GetStbMessageCount")
            {
                processGetStbMessageCount(resp, acceptGzip);
            }
            else // bad message type...
            {
                sendBadRequest(resp);
            }
        }
    }

    void parseReport(const Json::Value &root)
    {
        Json::Value const &payloadObj = root["payload"];
        if (payloadObj == nullValue)
        {
            //            cout << "payload json object not found!" << endl;
        }
        else
        {
            Json::Value::Members const payload = payloadObj.getMemberNames();
            if (payload.size() > 0)
            {
                //                cout << "payload:" << endl;
                Json::Value const &keys = payloadObj["keys"];
                if (keys != nullValue)
                {
                    //                    cout << "    keys:" << endl;
                    for (unsigned int i = 0; i < keys.size(); i++)
                    {
                        Json::Value const &keyEntry = keys[i];
                        Json::Value const &keyName = keyEntry["keyName"];
                        if (keyName != nullValue)
                        {
                            //                            cout << " keyName:"
                            //                                 <<
                            // keyName.toStyledString() << endl;
                        }
                        Json::Value const &sampleObj = keyEntry["keyValue"];
                        if (sampleObj != nullValue)
                        {
                            //                            cout << "
                            // samples:" << endl;
                            for (unsigned int j = 0; j < sampleObj.size(); j++)
                            {
                                Json::Value const &sample = sampleObj[j];
                                Json::Value const &tsValue = sample["tstamp"];
                                if (tsValue != nullValue)
                                {
                                    //                                    cout
                                    // << "            tstamp:"
                                    //                                         <<
                                    // tsValue.asInt() << endl;
                                }
                                Json::Value const &status = sample["status"];
                                //                                cout << "
                                // status:" << status.asInt()
                                //                                     << endl;
                                if (sample.isMember("value"))
                                {
                                    Json::Value const &value = sample["value"];
                                    //                                    cout
                                    // << "            value:"
                                    //                                         <<
                                    // (value != nullValue ?
                                    //                                                 value.toStyledString()
                                    // :
                                    //                                                 "null")
                                    // << endl;
                                }
                                else
                                {
                                    //                                    cout
                                    // << "            value: not found!!!";
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    void parseSTBMessage(string &buffString)
    {
        Json::Value root;
        Json::Reader parser;
        if (parser.parse(buffString, root))
        {
            Json::Value const &hdr = root["hdr"];
            Json::Value const &messageType = hdr["messageType"];
            if (hdr != nullValue && messageType != nullValue)
            {
                switch (messageType.asInt())
                {
                    case 2: // GPV response
                        cout << "GPV response" << endl;
                        parseReport(root);
                        break;
                    case 4: // SPV response
                        cout << "SPV response" << endl;
                        parseReport(root);
                        break;
                    case 5: // Boot
                        cout << "Boot notification" << endl;
                        break;
                    case 6: // IV
                        cout << "IV complete notification" << endl;
                        break;
                    case 7: // Report
                        cout << "Report samples" << endl;
                        parseReport(root);
                        break;
                    defaulf:
                        cout << "MessageType is unknown" << endl;
                        break;
                }
                cout << endl;
            }
        }
        else
        {
            cout << "Can't parse payload!!!" << endl;
        }
    }

    void convertReportToXml(Poco::XML::Document &doc,
                            Poco::XML::Element *msgElement,
                            const Json::Value &root)
    {
        Json::Value const &payloadObj = root["payload"];
        if (payloadObj == nullValue)
        {
            cout << "payload json object not found!" << endl;
        }
        else
        {
            Poco::XML::Element *payloadXml = doc.createElement("payload");
            msgElement->appendChild(payloadXml);

            Json::Value::Members const payload = payloadObj.getMemberNames();
            if (payload.size() > 0)
            {
                cout << "payload:" << endl;
                Json::Value const &keys = payloadObj["keys"];
                if (keys != nullValue)
                {
                    cout << "    keys:" << endl;
                    Poco::XML::Element *keysXml = doc.createElement("keys");
                    payloadXml->appendChild(keysXml);

                    for (unsigned int i = 0; i < keys.size(); i++)
                    {
                        Json::Value const &keyEntry = keys[i];
                        Json::Value const &keyName = keyEntry["keyName"];
                        if (keyName != nullValue)
                        {
                            cout << "        keyName:"
                                 << keyName.toStyledString() << endl;
                        }
                        Poco::XML::Element *keyXml = doc.createElement("key");
                        Poco::XML::Element *keyNameXml =
                            doc.createElement("keyName");
                        keyNameXml->appendChild(
                            doc.createTextNode(keyName.toStyledString()));
                        keyXml->appendChild(keyNameXml);
                        keysXml->appendChild(keyXml);
                        Json::Value const &sampleObj = keyEntry["keyValue"];
                        if (sampleObj != nullValue)
                        {
                            cout << "        samples:" << endl;
                            Poco::XML::Element *samplesXml =
                                doc.createElement("keyValue");
                            for (unsigned int j = 0; j < sampleObj.size(); j++)
                            {
                                Poco::XML::Element *sampleXml =
                                    doc.createElement("sample");
                                Json::Value const &sample = sampleObj[j];
                                Json::Value const &tsValue = sample["tstamp"];
                                if (tsValue != nullValue)
                                {
                                    cout << "            tstamp:"
                                         << tsValue.asInt() << endl;
                                    Poco::XML::Element *tsXml =
                                        doc.createElement("tstamp");
                                    tsXml->appendChild(doc.createTextNode(
                                        tsValue.toStyledString()));
                                    sampleXml->appendChild(tsXml);
                                }
                                Json::Value const &status = sample["status"];
                                if (status != nullValue)
                                {
                                    cout << "            status:"
                                         << status.asInt() << endl;
                                    Poco::XML::Element *statusXml =
                                        doc.createElement("status");
                                    statusXml->appendChild(doc.createTextNode(
                                        status.toStyledString()));
                                    sampleXml->appendChild(statusXml);
                                }
                                if (sample.isMember("value"))
                                {
                                    Json::Value const &value = sample["value"];
                                    cout << "            value:"
                                         << (value != nullValue ?
                                                 value.toStyledString() :
                                                 "null") << endl;
                                    Poco::XML::Element *valueXml =
                                        doc.createElement("value");
                                    valueXml->appendChild(doc.createTextNode(
                                        value != nullValue ?
                                            value.toStyledString() :
                                            "null"));
                                    sampleXml->appendChild(valueXml);
                                }
                                else
                                {
                                    cout << "            value: not found!!!"
                                         << endl;
                                    Poco::XML::Element *valueXml =
                                        doc.createElement("value");
                                    valueXml->appendChild(
                                        doc.createTextNode("missing!!!"));
                                    sampleXml->appendChild(valueXml);
                                }
                                samplesXml->appendChild(sampleXml);
                            }
                            keyXml->appendChild(samplesXml);
                        }
                    }
                }
            }
        }
    }

    void convertStbMessageToXml(Poco::XML::Document &doc, string &buffString)
    {
        Json::Value root;
        Json::Reader parser;

        if (parser.parse(buffString, root))
        {
            cout << "Parsed for XML build OK" << endl;

            Json::Value const &hdr = root["hdr"];
            Json::Value const &messageType = hdr["messageType"];

            cout << "searched for message type" << endl;

            if ((hdr == nullValue) || (messageType == nullValue))
            {
                cout << "hdr or messageType was null" << endl;
                return;
            }

            Poco::XML::Element *msgElement = doc.createElement("message");
            doc.appendChild(msgElement);

            // hdr
            Poco::XML::Element *hdrXml = doc.createElement("hdr");
            cout << "hdr:" << endl;
            Json::Value::Members members = root["hdr"].getMemberNames();
            Json::Value::Members::iterator memberIt = members.begin();
            while (memberIt != members.end())
            {
                std::string tmpValue = hdr[*memberIt].toStyledString();
                cout << "    " << memberIt->data() << ":" << tmpValue << endl;

                if ((*memberIt).find("/") != std::string::npos)
                {
                    Poco::XML::Element *keyXml = doc.createElement("key");
                    Poco::XML::Element *keyNameXml =
                        doc.createElement("keyName");
                    keyNameXml->appendChild(
                        doc.createTextNode(memberIt->data()));
                    Poco::XML::Element *tmpNameValue =
                        doc.createElement("value");
                    tmpNameValue->appendChild(
                        doc.createTextNode(hdr[*memberIt].toStyledString()));
                    keyXml->appendChild(keyNameXml);
                    keyXml->appendChild(tmpNameValue);
                    hdrXml->appendChild(keyXml);
                }
                else
                {
                    Poco::XML::Element *tmpTagXml =
                        doc.createElement(*memberIt);
                    tmpTagXml->appendChild(doc.createTextNode(tmpValue));
                    msgElement->appendChild(tmpTagXml);
                }

                memberIt++;
            }
            msgElement->appendChild(hdrXml);

            switch (messageType.asInt())
            {
                case 2: // GPV response
                    cout << "GPV response" << endl;
                    convertReportToXml(doc, msgElement, root);
                    break;
                case 4: // SPV response
                    cout << "SPV response" << endl;
                    convertReportToXml(doc, msgElement, root);
                    break;
                case 5: // Boot
                    cout << "Boot notification" << endl;
                    break;
                case 6: // IV
                    cout << "IV complete notification" << endl;
                    break;
                case 7: // Report
                    cout << "Report samples" << endl;
                    convertReportToXml(doc, msgElement, root);
                    break;
            }
            cout << endl;
        }
        else
        {
            cout << "Can't parse payload!!!" << endl;
        }

        return;
    }

    void
    getGZipFlags(const HTTPServerRequest &req, bool &isGzip, bool &acceptGzip)
    {
        isGzip = false;
        acceptGzip = false;
        for (Poco::Net::NameValueCollection::ConstIterator iter = req.begin();
             iter != req.end();
             ++iter)
        {
            std::string hdr = iter->first;
            std::transform(hdr.begin(), hdr.end(), hdr.begin(), ::tolower);
            if (hdr == "content-encoding" && iter->second == "gzip")
            {
                isGzip = true;
            }
            if (hdr == "accept-encoding")
            {
                // half-hearted attempt at checking qvalue - only care if it's
                // zero and don't look at other priorities
                std::string v(iter->second);
                size_t pos = v.find("gzip;q=0");
                if (pos != string::npos)
                {
                    // gzip is explicitly NOT acceptable
                    acceptGzip = false;
                }
                else
                {
                    pos = v.find("gzip");
                    if (pos != string::npos)
                    {
                        acceptGzip = true;
                    }
                }
            }
        }
    }

    void sendStbResponse(HTTPServerRequest &req, HTTPServerResponse &resp)
    {
        bool isGzip = false;
        bool acceptGzip = false;
        std::stringstream headerSS;
        for (Poco::Net::NameValueCollection::ConstIterator iter = req.begin();
             iter != req.end();
             ++iter)
        {
            cout << iter->first << ": " << iter->second << endl;
            headerSS << iter->first << ": " << iter->second << std::endl;
        }
        factory->addHttpHeaders(headerSS.str());
        cout << endl;

        getGZipFlags(req, isGzip, acceptGzip);

        if (isGzip && refuseGzip)
        {
            // Refuse to process this message
            std::cout << "\n***** Request is gzip, I'm going to refuse it *****"
                      << std::endl;
            resp.setStatusAndReason(
                Poco::Net::HTTPResponse::HTTP_UNSUPPORTEDMEDIATYPE);
            sendJsonResponse(resp, "", false, true);
        }
        else
        {
            std::string buffString;
            istream &inputStream = req.stream();

            if (!isGzip)
            {
                buffString =
                    std::string((std::istreambuf_iterator<char>(inputStream)),
                                std::istreambuf_iterator<char>());
            }
            else
            {
                Poco::InflatingInputStream inflater(
                    inputStream, Poco::InflatingStreamBuf::STREAM_GZIP);
                std::stringstream out_unzipped;
                out_unzipped << inflater.rdbuf();
                buffString = out_unzipped.str();
            }

            cout << buffString << endl;

            //        char* buff = new char[req.getContentLength()+1];
            //        inputStream.read(buff, req.getContentLength());
            //        buff[req.getContentLength()] = '\0';
            //        cout << "body:" << buff << endl;
            //        std::string buffString(buff);
            if (factory->getOutputFormat() == XML)
            {
                buffString.erase(
                    std::remove(buffString.begin(), buffString.end(), '\\'),
                    buffString.end());
                parseSTBMessage(buffString);
                XMLDocPtr doc = new Poco::XML::Document;
                convertStbMessageToXml(*doc, buffString);
                std::string str;
                getXmlText(str, doc);
                factory->addStbMessage(str);
            }
            else
            {
                factory->addStbMessage(buffString);
            }


            switch (factory->getResponseType())
            {
                case SEND_GPV:
                {
                    cout << "\n***** Sending GPV *****" << endl;
                    Json::Value msgRoot;
                    msgRoot["messageType"] = 1;
                    msgRoot["version"] = 0;
                    vector<string>::iterator keyIt =
                        factory->getGpvKeyList().begin();
                    while (keyIt != factory->getGpvKeyList().end())
                    {
                        Json::Value keyName;
                        keyName["keyName"] = keyIt->data();
                        msgRoot["payload"]["keys"].append(keyName);
                        keyIt++;
                    }

                    resp.setStatusAndReason((HTTPResponse::HTTPStatus)factory
                                                ->getNextStbResponseStatus());
                    sendJsonResponse(
                        resp, msgRoot.toStyledString(), acceptGzip, true);
                }
                break;
                case SEND_SPV:
                {
                    cout << "\n***** Sending SPV *****" << endl;
                    Json::Value msgRoot;
                    msgRoot["messageType"] = 3;
                    msgRoot["version"] = 0;
                    map<string, string>::iterator keyValIt =
                        factory->getSpvKeyValueList().begin();
                    while (keyValIt != factory->getSpvKeyValueList().end())
                    {
                        Json::Value keyName;
                        keyName["keyName"] = keyValIt->first;
                        // Parse JSON format string to value, JSONCPP doesn't
                        // seem to have a way to do this.
                        std::string &value(keyValIt->second);
                        if (value.length() > 2 && value.at(0) == '"' &&
                            value.at(value.length() - 1) == '"')
                        {
                            keyName["keyValue"] =
                                value.substr(1, value.length() - 2); // string
                        }
                        else if (value == "false")
                        {
                            keyName["keyValue"] = false; // bool false
                        }
                        else if (value == "true")
                        {
                            keyName["keyValue"] = true; // bool true
                        }
                        else
                        {
                            int32_t i;
                            std::istringstream ss(value);
                            ss >> i;
                            if (!ss.fail())
                            {
                                keyName["keyValue"] = i; // number - int
                            }
                            else
                            {
                                std::istringstream ss2(value);
                                double d;
                                ss2 >> d;
                                if (!ss2.fail())
                                {
                                    keyName["keyValue"] = d; // number - float
                                }
                                else
                                {
                                    std::cout << "Not sure how to json decode >"
                                              << value << "<" << std::endl;
                                    keyName["keyValue"] =
                                        value; // final failsafe
                                }
                            }
                        }
                        msgRoot["payload"]["keys"].append(keyName);
                        keyValIt++;
                    }
                    resp.setStatusAndReason((HTTPResponse::HTTPStatus)factory
                                                ->getNextStbResponseStatus());
                    sendJsonResponse(
                        resp, msgRoot.toStyledString(), acceptGzip, true);
                }
                break;
                case NONE:
                {
                    cout << "\n***** Sending empty response (status "
                         << factory->getEmptyStbResponseStatus() << ") *****"
                         << endl;
                    resp.setStatusAndReason((HTTPResponse::HTTPStatus)factory
                                                ->getEmptyStbResponseStatus());
                    sendJsonResponse(resp, "", false, true);
                }
                break;
                default:
                    break;
            }
        }
    }

    void dumpXmlDocument(Poco::XML::Document *doc)
    {
        // cout << "enter dumpXmlDocument" << endl;
        Poco::XML::DOMWriter writer;
        stringstream ss;
        writer.setNewLine("\n");
        writer.setOptions(Poco::XML::XMLWriter::PRETTY_PRINT);
        writer.writeNode(ss, doc);
        cout << "XML:" << ss.str() << endl;
    }

    void getXmlText(string &str, Poco::XML::Document *doc)
    {
        // cout << "enter getXmlText" << endl;
        Poco::XML::DOMWriter writer;
        stringstream ss;
        writer.setNewLine("\n");
        writer.writeNode(ss, doc);
        str = ss.str();
        cout << "exit getXmlText:" << endl << str << endl;
    }

    void processGetStbMessages(const Poco::Net::HTMLForm &form,
                               HTTPServerResponse &resp,
                               bool gzipResponse = false)
    {
        string idxStr = form.has("index") ? form.get("index") : "-1";
        int index;
        istringstream(idxStr) >> index;
        // cout << "GetStbMessage: index=" << index << endl;
        if (index >= 0 &&
            (unsigned)(index) < factory->getStbMessageList().size())
        {
            string msgStr = factory->getStbMessageList()[index];
            //   cout << "GetStbMessage: msgStr:" << msgStr << endl;
            // get the message at idx # and return as response
            sendResponse(resp, msgStr, gzipResponse);
        }
        else
        {
            sendBadRequest(resp);
        }
    }

    void processGetHttpHeaders(const Poco::Net::HTMLForm &form,
                               HTTPServerResponse &resp,
                               bool gzipResponse = false)
    {
        string idxStr = form.has("index") ? form.get("index") : "-1";
        int index;
        istringstream(idxStr) >> index;
        // cout << "GetStbMessageHeaders: index=" << index << endl;
        if (index >= 0 &&
            (unsigned)(index) < factory->getHttpHeaderList().size())
        {
            string hdrStr = factory->getHttpHeaderList()[index];
            // cout << "GetStbMessageHeaders: headers:" << hdrStr << endl;
            // get the message at idx # and return as response
            sendResponse(resp, hdrStr, gzipResponse);
        }
        else
        {
            sendBadRequest(resp);
        }
    }

    void processGetStbMessageCount(HTTPServerResponse &resp,
                                   bool gzipResponse = false)
    {
        stringstream ss;
        ss << factory->getStbMessageList().size();
        //  cout << "GetStbMessageCount, count is "
        //      << factory->getStbMessageList().size() << endl;
        sendResponse(resp, ss.str(), gzipResponse);
    }

    void processSPVSetup(const Poco::Net::HTMLForm &form,
                         HTTPServerResponse &resp)
    {
        factory->setResponseType(SEND_SPV);
        factory->getSpvKeyValueList().clear();
        int httpStatus = 200;
        Poco::Net::NameValueCollection::ConstIterator it = form.begin();
        while (it != form.end())
        {
            //            cout << "name:" << it->first << " value: " <<
            // it->second << endl;
            if (it->first == "messageType")
            {
                ++it;
                continue;
            }

            if (it->first == "status")
            {
                std::istringstream iss(it->second);
                iss >> httpStatus;
            }
            else
            {
                factory->getSpvKeyValueList().insert(
                    make_pair(it->first, it->second));
            }
            it++;
        }
        factory->setNextStbResponseStatus(httpStatus);
        sendResponse(resp, "SPV set\n");
    }

    void processGPVSetup(const Poco::Net::HTMLForm &form,
                         HTTPServerResponse &resp)
    {
        factory->setResponseType(SEND_GPV);
        factory->getGpvKeyList().clear();
        int httpStatus = 200;
        Poco::Net::NameValueCollection::ConstIterator it = form.begin();
        while (it != form.end())
        {
            //            cout << "name:" << it->first << " value: " <<
            // it->second << endl;
            if (it->first == "key")
            {
                factory->getGpvKeyList().push_back(it->second);
            }
            else if (it->first == "status")
            {
                std::istringstream iss(it->second);
                iss >> httpStatus;
            }
            it++;
        }
        factory->setNextStbResponseStatus(httpStatus);
        sendResponse(resp, "GPV set\n");
    }

    void processNoneSetup(HTTPServerResponse &resp)
    {
        factory->setResponseType(NONE);
        sendResponse(resp, "no response set");
    }

    void processClearStbMessages(HTTPServerResponse &resp)
    {
        //        cout << "ClearSTBMessages" << endl;
        factory->getStbMessageList().clear();
        factory->getHttpHeaderList().clear();
        sendResponse(resp, "STB messages deleted\n");
    }

    void sendBadRequest(HTTPServerResponse &resp)
    {
        resp.setStatus(HTTPResponse::HTTP_REASON_BAD_REQUEST);
        resp.setContentLength(0);
    }
};

class MyRequestHandlerFactory : public HTTPRequestHandlerFactory,
                                MyFactoryInterface
{
public:
    MyRequestHandlerFactory(OutputFormat of,
                            bool refuseGzip,
                            bool allowGzipResponse,
                            int emptyResponseStatus)
        : responseType(NONE),
          outputFormat(of),
          refuseGzip(refuseGzip),
          allowGzipResponse(allowGzipResponse),
          emptyResponseStatus(emptyResponseStatus),
          nextStbResponseStatus(HTTPResponse::HTTP_OK)
    {
    }
    virtual HTTPRequestHandler *createRequestHandler(const HTTPServerRequest &)
    {
        MyRequestHandler *newHandler =
                new MyRequestHandler(this, refuseGzip, allowGzipResponse);
        newHandler->setResponseType(responseType);
        return newHandler;
    }

    vector<string> &getGpvKeyList()
    {
        return gpvKeyList;
    }

    SendOp getResponseType()
    {
        return responseType;
    }
    int getNextStbResponseStatus()
    {
        return nextStbResponseStatus;
    }
    int getEmptyStbResponseStatus()
    {
        return emptyResponseStatus;
    }

    void setResponseType(SendOp responseType)
    {
        this->responseType = responseType;
    }
    void setNextStbResponseStatus(int status)
    {
        this->nextStbResponseStatus = status;
    }

    map<string, string> &getSpvKeyValueList()
    {
        return spvKeyValueList;
    }

    vector<std::string> &getStbMessageList()
    {
        return stbMessageList;
    }

    void addStbMessage(std::string const &message)
    {
        stbMessageList.push_back(message);
    }

    vector<std::string> &getHttpHeaderList()
    {
        return httpHeaderList;
    }

    void addHttpHeaders(std::string const &message)
    {
        httpHeaderList.push_back(message);
    }

    virtual OutputFormat getOutputFormat()
    {
        return outputFormat;
    }

private:
    SendOp responseType;
    vector<string *> stbResponses;
    vector<string> gpvKeyList;
    map<string, string> spvKeyValueList;
    vector<std::string> stbMessageList;
    vector<std::string> httpHeaderList;
    OutputFormat outputFormat;
    bool refuseGzip;
    bool allowGzipResponse;
    int emptyResponseStatus;
    int nextStbResponseStatus;
};

class MyServerApp : public ServerApplication
{
protected:
    int main(const vector<string> &args)
    {
        OutputFormat of = XML;
        bool refuseGzip = false;
        bool allowGzipResponse = false;
        bool useHttps = false;
        int emptyResponseStatus = 200;
        if (args.size() >= 1 && args.at(0) == "json")
        {
            cout << endl << "Using JSON output format" << endl;
            of = JSON;
        }
        if (args.size() >= 1 && args.at(0) == "json+https")
        {
            cout << endl << "Using JSON output format over HTTPS" << endl;
            of = JSON;
            useHttps = true;
        }
        int port = 8090;
        if (args.size() >= 2)
        {
            std::istringstream iss(args.at(1));
            iss >> port;
        }
        if (args.size() >= 3 && args.at(2) == "nogzip")
        {
            cout << endl << "Refusing gzip" << endl;
            refuseGzip = true;
        }
        else if (args.size() >= 3 && args.at(2) == "allowgzipresponse")
        {
            cout << endl << "Allows gzip of response" << endl;
            allowGzipResponse = true;
        }
        else if (args.size() >= 4 && args.at(2) == "emptyResponseStatus")
        {
            std::istringstream iss(args.at(3));
            iss >> emptyResponseStatus;
            cout << endl << "Empty response to STB messages will have status "
                 << emptyResponseStatus << endl;
        }

        if (useHttps)
        {
            initializeSSL();
            SSLManager::instance().initializeServer(new KeyConsoleHandler(true), new AcceptCertificateHandler(true),
                    new Context(Context::SERVER_USE, "keys/server.key", "keys/server.crt", "keys/ca.crt"));
        }

        MyRequestHandlerFactory *handler = new MyRequestHandlerFactory(
            of, refuseGzip, allowGzipResponse, emptyResponseStatus);
        const IPAddress addr = IPAddress();
        SocketAddress saddr(addr, port);
        Poco::SharedPtr<ServerSocket> serverSocket;
        if (useHttps)
            serverSocket.assign(new SecureServerSocket(saddr, true));
        else
            serverSocket.assign(new ServerSocket(saddr, true));

        HTTPServer s(handler, *serverSocket, new HTTPServerParams);

        s.start();
        cout << endl << "Server started,  port " << port << endl;

        waitForTerminationRequest(); // wait for CTRL-C or kill

        cout << endl << "Shutting down..." << endl;
        s.stop();

        return Application::EXIT_OK;
    }
};

int main(int argc, char **argv)
{
    MyServerApp app;
    return app.run(argc, argv);
}
